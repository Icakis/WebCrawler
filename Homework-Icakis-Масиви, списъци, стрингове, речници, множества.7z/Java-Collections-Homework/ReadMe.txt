Some sites have defence and can't be crawled.  (zamunda.net)
Level of search - 1 or 2, bigger then that it become very slow.